import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox
import os

class MediaPlayer(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Media Player")
        self.geometry("400x300")

        self.playlist = ttk.Treeview(self)
        self.playlist.pack()

        self.menubar = tk.Menu(self)
        self.config(menu=self.menubar)

        self.file_menu = tk.Menu(self.menubar)
        self.menubar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="Open", command=self.open_file)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.exit)

    def open_file(self):
        options = {"defaultextension": ".mp3", "filetypes": [("Audio files", "*.mp3;*.wav")]}
        filepath = filedialog.askopenfilename(**options)
        if filepath:
            self.playlist.insert("", "end", text=os.path.basename(filepath), values=(filepath,))

    def exit(self):
        if messagebox.askyesno("Exit", "Are you sure you want to exit the player?"):
            self.destroy()

if __name__ == "__main__":
    player = MediaPlayer()
    player.mainloop()
