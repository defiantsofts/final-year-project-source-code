import pygame
import os

class MediaPlayer(tk.Tk):
    def __init__(self):
        pass
        # ... existing code ...

    def open_file(self):
        options = {"defaultextension": ".mp3", "filetypes": [("Audio files", "*.mp3;*.wav"),("Video files", "*.mp4;*.avi;*.mkv")]}
        filepath = filedialog.askopenfilename(**options)
        if filepath:
            if filepath.endswith(('.mp3', '.wav')):
                self.playlist.insert("", "end", text=os.path.basename(filepath), values=(filepath,))
                self.play_audio(filepath)
            elif filepath.endswith(('.mp4', '.avi', '.mkv')):
                self.play_video(filepath)

    def play_audio(self, filepath):
        # ... existing code to play audio ...
        pass

    def play_video(self, filepath):
        pygame.init()
        pygame.mixer.quit()
        pygame.display.set_caption("Media Player")
        screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Media Player")
        pygame.display.set_caption(filepath)
        movie = pygame.movie.Movie(filepath)
        movie_screen = pygame.Surface((800, 600))
        movie.set_display(movie_screen)
        movie.play()
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    movie.stop()
                    pygame.display.quit()
                    pygame.quit()
                    exit()
            screen.blit(movie_screen, (0, 0))
            pygame.display.update()
